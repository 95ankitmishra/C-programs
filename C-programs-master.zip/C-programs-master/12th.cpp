#include<stdio.h>
#include<conio.h>
int main()
{
	int i,n;
	printf("enter a value:");
	scanf("%d",&n);
	i=2;
	while(i<=n)
	{
		printf("%d\n",i);
		i=i+2;
	}
}
