#include<stdio.h> 
#include<conio.h>
int main()
{
	int age=10;
	float salary=1500.50;
	printf("address of age is :=%p\n",&age);
	printf("address of salary=%p\n",&salary);
	return 0;
}
