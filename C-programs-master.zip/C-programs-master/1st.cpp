#include<stdio.h>
#include<conio.h>
int main()
{
  printf("A");
  printf("B");
  if(5<2)
  {
  	printf("welcome");
  	printf("Hello");
  }
  printf("X");
  printf("Y");
  getch();
  }
