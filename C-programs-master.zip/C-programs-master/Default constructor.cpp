#include<iostream>
using namespace std;
class Madhu
{
	public:
		Madhu()
		{
			cout<<"madhu is a good boy:"<<endl;
		}
};
int main()
{
	Madhu m1,m2,m3;
	return 0;
}
