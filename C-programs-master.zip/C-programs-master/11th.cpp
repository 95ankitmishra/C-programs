#include<stdio.h>
#include<conio.h>
int main()
{
	int i;
	i=10;
	while(i>=1)
	{
		printf("%d",i);
		i=i-1;
	}
}
