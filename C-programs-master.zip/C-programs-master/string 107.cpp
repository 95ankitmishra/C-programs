#include<stdio.h>
#include<conio.h>
int main()
{
	char str[10]="welcome";
	printf(" %s",str);
	getch();
	return 0;
}
