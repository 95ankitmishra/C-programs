#include<stdio.h>
#include<conio.h>
void abc()
{
	auto int a=5;
	++a;
	printf("\n a=%d",a);
}
int main()
{
	abc();
	abc();
	abc();
}
