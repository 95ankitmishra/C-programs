#include<iostream>
using namespace std;
class Mad
{
	public:
		Mad()
		{
			cout<<"i am a default constructor:"<<endl;
		}
};
int main()
{
	Mad m1,m2,m3;
	return 0;
}
