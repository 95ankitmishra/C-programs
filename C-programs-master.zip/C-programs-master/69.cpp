#include<stdio.h>
#include<conio.h>
#include<math.h>
int main()
{

int n,s;
printf("enter a number:");
scanf("%d",&n);
s=sqrt(n);
printf("square root of %d is%d\n",n,s);
return 0;
}
