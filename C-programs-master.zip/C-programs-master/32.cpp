 #include<stdio.h>
 #include<conio.h>
 int main()
 {
 	printf("madhu tum\n");
 	printf("na chor nhi");
 	goto ABC;
 	printf("welcome");
 	ABC:
 		printf("\n ho kutta");
 		printf("\nho");
 }
