#include<stdio.h>
#include<conio.h>
int main()
{
	printf("NIT");
	if(5>2 && 5<8)
	{
		printf("A");
		printf("B");
	}
	else
	{
		printf("X");
		printf("Y");
	}
}
