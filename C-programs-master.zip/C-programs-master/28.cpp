#include<stdio.h>
#include<conio.h>
int main()
{
	int a;
	a=5;
	printf("%d %d %d",a,a,a=10);
	
}
