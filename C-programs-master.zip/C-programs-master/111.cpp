#include<stdio.h>
#include<conio.h>
int main()
{
	char str[10]="welcome";
	int i;
	for(i=0;str[i]!='\0';i++)
	{
		puts(str+i);
	}
	return 0;
}
