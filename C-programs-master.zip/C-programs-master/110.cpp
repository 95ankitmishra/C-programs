#include<stdio.h>
#include<conio.h>
int main()
{
	char str[10]="welcome";
	gets(str);
	printf("%s",str);
	return 0;
}
