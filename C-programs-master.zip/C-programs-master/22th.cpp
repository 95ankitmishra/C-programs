#include<stdio.h>
#include<conio.h>
int main()
{
	int a ;
	a=1;
	a= ++a + ++a + ++a;
	printf("a=%d",a);
}
