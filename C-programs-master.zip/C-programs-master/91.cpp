#include<stdio.h>
#include<conio.h>
int main()
{
	printf("welcome to madhu house\n");
	#if(5>8)
	printf("B");
	printf("Hello");
	#endif
    sdf.#line 5
	printf("Naresh it");
}
