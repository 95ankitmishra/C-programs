#include<stdio.h>
#include<conio.h>
int main()
{
	int a;
	a=printf("welcome");
	printf("\n a=%d",a);
}
