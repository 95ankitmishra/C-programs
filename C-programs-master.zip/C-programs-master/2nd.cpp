#include<iostream>
using namespace std;
int main()
{
	int num1,num2,sum,avg;
	cout<<"enter two number";
	cin>>num1>>num2;
	sum=num1+num2;
	avg=sum/2;
	cout<<"sum of two number"<<sum<<endl;
	cout<<"average of two number"<<avg;
	return 0;
}
