#include<stdio.h>
#include<conio.h>
int main()
{
	printf("NIT");
	printf("welcome");
	XYZ:
		printf("x");
		printf("y");
		goto ABC;
			printf("Hello");
			ABC:
				printf("A");
				printf("B");
}
