#include<stdio.h>
#include<conio.h>
int main()
{
	printf("B");
	if(!5!=0)
	{
		printf("welcome");
		printf("NIT");
		printf("A");
	}
}
