#include<stdio.h>
#include<conio.h>
int main()
{
	int a;
	a=printf("one\n,two\n",printf("three\n"));
	printf("\na=%d",a);
}
