#include<iostream>
#include<string.h>
using namespace std;
int main()
{
	int c;
	char str1[]="HELLO";
	char str2[]="HELLO";
	c=strcmp(str1,str2);
	cout<<c;
}
