#include<iostream>
#include<string.h>
using namespace std;
int main()
{
	char str[]="hello";
	char str1[20];
	strcpy(str1,str);
	cout<<"copy is done:"<<str1;
	
}
