#include<stdio.h>
#include<conio.h>
int main()
{
	printf("oracle");
	if(!5!=5)
	{
	
	printf("B");
	printf("A");}
	else
	{
		printf("welcome");
		printf("NIT");
	}
}
