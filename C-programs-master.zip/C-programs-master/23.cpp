#include<stdio.h>
#include<conio.h>
int main()
{
	int a,b;
	a=10;
	b=++a;
	printf("value of b is =%d",b);
	printf("after increment value of a is:%d",a);
}
