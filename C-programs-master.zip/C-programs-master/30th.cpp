#include<stdio.h>
#include<conio.h>
int main()
{
	printf("A");
	printf("B");
	if(5<2);
	{
		printf("NIT");
		printf("welcome");
	}
	printf("x");
	printf("Y");
}
