#include<stdio.h>
#include<conio.h>
int main()
{
	int a;
	a=0;
	if(a=10)
	printf("welcome %d",a);
	else
	printf("hello %d",a);
}
