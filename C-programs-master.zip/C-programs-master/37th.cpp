#include<stdio.h>
#include<conio.h>
int main()
{
	double d=12345.6789;
	int l;
	l=(int)d;
	printf("%d %lf",l,d);
}
