#include<stdio.h>
#include<conio.h>
int main()
{
	char str[]="welcome";
	printf("\n %s",str);
	printf("\n %s",str+3);
	printf("\n %s",str+5);
	getch();
	return 0;
}
