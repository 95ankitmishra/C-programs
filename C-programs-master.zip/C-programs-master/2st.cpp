#include<stdio.h>
#include<conio.h>
int main()
{
	printf("welcome");
	if(1!=2>5!=0)
	{
		printf("A");
		printf("B");
	}
	printf("Hello");
}
