#include<iostream>
using namespace std;
int main()
{
	char str1[6]={'H','E','E','L','0'};
	char str2[6]="hello";
	char str3[]="hello";
	cout<<"string is:"<<str1<<endl;
	cout<<"string is:"<<str2<<endl;
	cout<<"string is:"<<str3<<endl;
}
