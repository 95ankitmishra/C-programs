#include<stdio.h>
#include<conio.h>
int main()
{
	printf("JAVA");
	if(1!=2<5||0!=5>8)
{
	printf("B");
	printf("A");
}
else
{
	printf("X");
	printf("Y");
}
}
