#include<stdio.h>
#include<conio.h>
int main()
{
	char str[10];
	printf("enter  a string:\n");
     gets(str);
	puts(str);
}
