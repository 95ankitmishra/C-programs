#include<stdio.h>
#include<conio.h>
int main()
{
int a;
a=printf("%d hello %d",100,200);
printf("\n a =%d",a);
}

